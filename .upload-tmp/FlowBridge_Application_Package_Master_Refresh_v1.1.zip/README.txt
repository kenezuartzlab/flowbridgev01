FlowBridge BOT Chain Application — v1.1 MASTER REFRESH (frozen 2026-10-12)
CANONICAL: the PDF files (Dossier, Whitepaper, Pitch Deck, On-chain Evidence Pack, Reviewer Summary).
DOCX/PPTX: Editable convenience copy — canonical version is the corresponding PDF.
FlowBridge_Onchain_Evidence_Data_v1.1.zip: supporting evidence archive.
Support requested: Option A — REQUESTED. Monitoring: pending BOT Chain approval/onboarding.
No funding amount requested. Compliance confirmation: OWNER ACTION. Not submitted.
